﻿## test loopback adapter
Describe 'Loopback Adapter' {
  It 'Loop back adapter should be pingable' {
    Test-Connection -ComputerName 127.0.0.1 -Quiet -Count 1 |
    Should Be $true
  }
}

## test local adapter
Describe 'Local Adapter' {
  It 'Local adapter should be pingable' {
    Test-Connection -ComputerName $netinfo.IPAddress -Quiet -Count 1 |
    Should Be $true
  }
}

##  test DNS server
Describe 'DNSServer' {
  It 'DNS server should be available' {
    Test-Connection -ComputerName $netinfo.DNSserver -Quiet -Count 1 | 
    Should Be $true
 
  }
}

##  test Default Gateway
Describe 'DefaultGateway' {
  It 'Default Gateway should be available' {
    Test-Connection -ComputerName $netinfo.DefaultGateway -Quiet -Count 1 | 
    Should Be $true
 
  }
}

## test server IP address
Describe 'Server IP address' {
  It 'Server IP address should be pingable' {
    Test-Connection -ComputerName $netinfo.ServerIP -Quiet -Count 1 |
    Should Be $true
  }
}

## test server name
Describe 'Server Name' {
  It 'Server name should be pingable' {
    Test-Connection -ComputerName $netinfo.Server -Quiet -Count 1 |
    Should Be $true
  }
}