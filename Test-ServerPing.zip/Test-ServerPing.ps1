﻿  param (
  [string]$ServerToTest
  )

function get-networkinformation {
  param (
  [string]$server
  )

  $nic = Get-NetAdapter -Name LAN

  $ip = Get-NetIPAddress -AddressFamily IPv4 -InterfaceAlias LAN

  $dg = Get-NetIPConfiguration -InterfaceAlias LAN

  $props = [ordered]@{
    iIndex         = $nic.InterfaceIndex
    iAlias         = $nic.InterfaceAlias
    Status         = if ($nic.InterfaceOperationalStatus -eq 1){'Up'}else{'Down'}
    IPAddress      = $ip.IPAddress
    PrefixLength   = $ip.PrefixLength
    DefaultGateway = $dg.IPv4DefaultGateway | select -ExpandProperty NextHop
    DNSserver      = ($dg.DNSServer).serverAddresses
    Server         = $server
    ServerIP       = Resolve-DnsName -Name $server | select -ExpandProperty IPAddress
  }

  New-Object -TypeName PSobject -Property $props
}

$netinfo = get-networkinformation -server $ServerToTest
$path = 'C:\Scripts\TroubleShooting\Tests\PingTests.ps1'

$tests = Get-Content -Path $path | 
Select-String -Pattern 'Describe' | 
foreach {
   (($_ -split 'Describe')[1]).Trim('{').Trim().Trim("'") 
}

$data = foreach ($test in $tests) {
$result = $null
$result = Invoke-Pester -Script @{Path = $path} -PassThru -TestName "$test" -Show None 

$props = [ordered]@{
    'Test' = $result.TestResult.Name
    'Result' = $result.TestResult.Result
    'Failure Message' = $result.TestResult.FailureMessage
  }
 New-Object -TypeName PSObject -Property $props

if ($result.FailedCount -gt 0) {break}
} 

$data | Format-Table -AutoSize -Wrap